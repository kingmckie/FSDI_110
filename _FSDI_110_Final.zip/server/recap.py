

def variables ():
    status = "found"
    price = 3000.99

    print(status)

    if price> 99:
        print("but its expensive")

def say_hi(name):
    print("Hi" + name)

def sum(num1, num2):
    result = num1 + num2
    print("The result is: " + str(result))

def divide(num1, num2):
    if num2 == 0:
        print('error: you can not divide by zero')
    else:
        result = num1/ num2
        print("The result is " + str(result))

def sum_all_numbers():
    numbers = [3123,509,-23,45,1405,44,-2456,45,1234,778,1124,70,2956,82]

    for num in numbers:
        if num < 100:
            print(num)

def count_numbers_less_than_100(num):
    count = 0
    total = 0
    for num in numbers:

        total += num
        
        if num <100:
            count +=1
    
    return count
print("The result is: " + str(count))
print("The total is: " + str(total))

# calls
variables()

say_hi("Ass hole")
say_hi("Bubba, you aint got no legs!!")

sum(21, 21)

divide(10, 2)
divide(-19, -2)
divide(0, 2)
divide(5, 0)

sum_all_numbers()