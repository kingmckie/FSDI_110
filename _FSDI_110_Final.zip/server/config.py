import pymongo
import certifi

developer = {
    "first": "Mark",
    "last": "McKie",
    "age": 37,
    "email": "emckie@sdgku.edu",
    "hobbies": ["code", "gazing into the sunset thinking of that special lady"],
    "address": {
        "num": 741,
        "street": "evergreen",
        "city": "springfield"
    }
}




con_str = "mongodb+srv://everaldmmckie:Test1234@cluster0.ocr8qeq.mongodb.net/?retryWrites=true&w=majority"
client = pymongo.MongoClient(con_str, tlsCAFile=certifi.where())
db = client.get_database("organika")